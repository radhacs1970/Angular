import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inlinetsc',
  template: `
    <p>
      inlinetsc works!
      <ng-content></ng-content>
      continuing with some text....
    </p>
  `,
  styles: [
    `
    p {
      font-size: 20px;
      color: brown;
    }
    `
  ]
})
export class InlinetscComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
