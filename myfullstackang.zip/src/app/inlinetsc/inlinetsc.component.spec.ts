import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InlinetscComponent } from './inlinetsc.component';

describe('InlinetscComponent', () => {
  let component: InlinetscComponent;
  let fixture: ComponentFixture<InlinetscComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InlinetscComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InlinetscComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
