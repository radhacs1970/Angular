import { Component, OnInit } from '@angular/core';
import { Room } from '../room';
import { RoomService } from '../room.service';
 
@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css'],
})
export class RoomComponent implements OnInit {
 roomArr: Room[];
  constructor( private roomserv: RoomService ) {
  }

  ngOnInit(): void {
    this.roomArr = this.roomserv.getAllrooms();
    console.log( this.roomArr);
  }

  AddadummyRoom(): void {
    let rm: Room = new Room(900, 20, 'special', 2000);
    this.roomserv.addaRoom(rm);
  }

}
