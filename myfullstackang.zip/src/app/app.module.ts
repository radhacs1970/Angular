import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { Routes, RouterModule } from '@angular/router';


import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';

import { LearntypescriptComponent } from './learntypescript/learntypescript.component';
import { DatabindComponent } from './databind/databind.component';
import { RoomComponent } from './room/room.component';
import { StructAttriComponent } from './struct-attri/struct-attri.component';
import { AppRoutingModule } from './app.routing';
import { HomeComponent } from './home/home.component';
import { GuestloginComponent } from './guestlogin/guestlogin.component';
import { GuestmainComponent } from './guestmain/guestmain.component';
import { ShowmyguestdetailsComponent } from './showmyguestdetails/showmyguestdetails.component';
import { GuestbookroomComponent } from './guestbookroom/guestbookroom.component';
import { GuestshowwalletComponent } from './guestshowwallet/guestshowwallet.component';
import { GuestbookinghistoryComponent } from './guestbookinghistory/guestbookinghistory.component';
import { ClassstyleComponent } from './classstyle/classstyle.component';
import { HighlightDirective } from './highlight.directive';
import { LifecyclesampleComponent } from './lifecyclesample/lifecyclesample.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { InlinetscComponent } from './inlinetsc/inlinetsc.component';
import { LearnpipeComponent } from './learnpipe/learnpipe.component';
import { LearnreactformComponent } from './learnreactform/learnreactform.component';
import { CustomdatepipePipe } from './customdatepipe.pipe';
import { ShowonestudentComponent } from './showonestudent/showonestudent.component';
import { ShowtrnbtndatesComponent } from './showtrnbtndates/showtrnbtndates.component';
import { InstrnComponent } from './instrn/instrn.component';

@NgModule({
  declarations: [
    AppComponent,
    LearntypescriptComponent,
    DatabindComponent,
    RoomComponent,
    StructAttriComponent,
    HomeComponent,
    GuestloginComponent,
    GuestmainComponent,
    ShowmyguestdetailsComponent,
    GuestbookroomComponent,
    GuestshowwalletComponent,
    GuestbookinghistoryComponent,
    ClassstyleComponent,
    HighlightDirective,
    LifecyclesampleComponent,
    ParentComponent,
    ChildComponent,
    InlinetscComponent,
    LearnpipeComponent,
    LearnreactformComponent,
    CustomdatepipePipe,
    ShowonestudentComponent,
    ShowtrnbtndatesComponent,
    InstrnComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
