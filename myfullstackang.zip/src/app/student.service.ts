import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { Student } from './student';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  private baseurl = "http://localhost:8081/stdwebapp/api/";
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    })
  };
  constructor(private httpClient: HttpClient) {}

  getAllStudents(): Observable<Student[]> {
    return this.httpClient.get<Student[]>(this.baseurl + 'std' )
          .pipe(catchError(this.errorHandler) );

  }

  getOneStudent(id: string): Observable<Student> {
    //eg http://localhost:8081/stdwebapp/api/std/5
    let url = this.baseurl + 'std/' + id;
    return this.httpClient.get<Student>(url)
          .pipe(catchError(this.errorHandler) );

  }

errorHandler(error) {
  let errorMessage = '';
  if ( error.error instanceof ErrorEvent) {
    // Get client-side error
    errorMessage = error.error.message;
  } else {
    // Get server-side error
    errorMessage = `Error Code details: ${error.status}\nMessage: ${error.message}`;
  }
  console.log(errorMessage);
  return throwError(errorMessage);
 }

 validateLoginStudent( un: string, pw: string): Observable<Student>{
  let sIn: Student = new Student(1, 'ab', 'em', un, pw);
  let url = this.baseurl + 'std/login';
  console.log( url );
  return this.httpClient.post<Student>(url,
              JSON.stringify( sIn ),
                this.httpOptions)
                .pipe(catchError(this.errorHandler) );

 }
}
