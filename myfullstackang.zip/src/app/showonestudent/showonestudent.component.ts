import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Student } from '../student';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-showonestudent',
  templateUrl: './showonestudent.component.html',
  styleUrls: ['./showonestudent.component.css']
})
export class ShowonestudentComponent implements OnInit {
  selStdId: any;
  stdO: Student;
  errMsg : string;
  constructor(private stdServ: StudentService,
              private actvR: ActivatedRoute) { }

  ngOnInit(): void {
    //this.selStdId = localStorage.getItem('stdselected'  );
    this.selStdId = this.actvR.snapshot.params['id'];
    console.log( this.selStdId);
    this.stdServ.getOneStudent(this.selStdId).subscribe(
      (data: Student) => {
        this.stdO = data;
      },
      (error: any) => {
        this.errMsg = 'No Student available';

      }
    );

  }

}
