import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowonestudentComponent } from './showonestudent.component';

describe('ShowonestudentComponent', () => {
  let component: ShowonestudentComponent;
  let fixture: ComponentFixture<ShowonestudentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowonestudentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowonestudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
