import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Training } from './training';


@Injectable({
  providedIn: 'root'
})
export class TrainingService {
  //localhost:8081/stdwebapp/api/training/2021-10-01/2021-10-30

  private baseurl = 'http://localhost:8081/stdwebapp/api/training/';
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    })
  };

  showTrnBtwDates( stDate: string, endDate: string): Observable<Training[]> {
    const url = this.baseurl + stDate + '/' + endDate;
    return this.httpClient.get<Training[]>(url)
          .pipe(catchError(this.errorHandler) );

  }

  insertTraining(cId: number, cName: string, 
        cStDate: string, cEndDate: string ):
        Observable<any> {
    const trn: Training = new Training(99, cId, cName, cStDate, cEndDate);
    const url = this.baseurl + 'instrain';
    console.log( url );
    return this.httpClient.post<any>(url,
                JSON.stringify( trn ),
                  this.httpOptions)
                  .pipe(catchError(this.errorHandler) );
  }
  constructor(private httpClient: HttpClient) { }
  errorHandler(error) {
    let errorMessage = '';
    if ( error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code details: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
   }
}
