import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guestbookroom',
  templateUrl: './guestbookroom.component.html',
  styleUrls: ['./guestbookroom.component.css']
})
export class GuestbookroomComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
