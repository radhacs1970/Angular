import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guestshowwallet',
  templateUrl: './guestshowwallet.component.html',
  styleUrls: ['./guestshowwallet.component.css']
})
export class GuestshowwalletComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
