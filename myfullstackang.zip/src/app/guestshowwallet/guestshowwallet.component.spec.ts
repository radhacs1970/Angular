import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestshowwalletComponent } from './guestshowwallet.component';

describe('GuestshowwalletComponent', () => {
  let component: GuestshowwalletComponent;
  let fixture: ComponentFixture<GuestshowwalletComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GuestshowwalletComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GuestshowwalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
