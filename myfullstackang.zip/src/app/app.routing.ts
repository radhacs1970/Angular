import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RoomComponent } from './room/room.component';
import { LearntypescriptComponent } from './learntypescript/learntypescript.component';
import { DatabindComponent } from './databind/databind.component';
import { StructAttriComponent } from './struct-attri/struct-attri.component';
import { HomeComponent } from './home/home.component';
import { GuestloginComponent } from './guestlogin/guestlogin.component';
import { GuestmainComponent } from './guestmain/guestmain.component';
import { ShowmyguestdetailsComponent } from './showmyguestdetails/showmyguestdetails.component';
import { GuestbookinghistoryComponent } from './guestbookinghistory/guestbookinghistory.component';
import { GuestshowwalletComponent } from './guestshowwallet/guestshowwallet.component';
import { GuestbookroomComponent } from './guestbookroom/guestbookroom.component';
import { ShowonestudentComponent } from './showonestudent/showonestudent.component';
import { ShowtrnbtndatesComponent } from './showtrnbtndates/showtrnbtndates.component';
import { InstrnComponent } from './instrn/instrn.component';

const groutes: Routes = [
  {path: 'mydetails', component: ShowmyguestdetailsComponent},
  {path: 'bookroom', component: GuestbookroomComponent},
  {path: 'wallet', component: GuestshowwalletComponent},
  {path: 'bookingHistory', component: GuestbookinghistoryComponent},
  {path: 'showtrn', component: ShowtrnbtndatesComponent},
  {path: 'insTraining', component: InstrnComponent},
];

const routes: Routes = [
  {path: 'room', component: RoomComponent},
  {path: 'typescript',
      component: LearntypescriptComponent},
  {path: 'databind', component: DatabindComponent},
  {path: 'iffor', component: StructAttriComponent},
  {path: 'home', component: HomeComponent},
  {path: 'onestd/:id', component: ShowonestudentComponent},
  {path: 'guestlogin', component: GuestloginComponent},
  {path: 'guestmain/:guestId', 
      component: GuestmainComponent,
      children: groutes},
  {path: '', redirectTo: 'home', pathMatch: 'full' },
  {path: '**', redirectTo: 'home' }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }