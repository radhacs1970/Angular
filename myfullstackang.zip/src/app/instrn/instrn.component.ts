import { Component, OnInit } from '@angular/core';
import { Training } from '../training';
import { NgForm } from '@angular/forms';
import { TrainingService } from '../training.service';

@Component({
  selector: 'app-instrn',
  templateUrl: './instrn.component.html',
  styleUrls: ['./instrn.component.css']
})
export class InstrnComponent implements OnInit {
  aCourseId: any;
  aCourseName: string;
  stDate: string;
  endDate: string;
  myTrn: Training;
  retMsg: any;

  constructor( private trnServ: TrainingService) { }

  ngOnInit(): void {
  }
  
  OnSubmit(trnForm: NgForm){
    console.log( trnForm.value.cId);
    console.log( trnForm.value.aCName);
    console.log( trnForm.value.sDt);
    console.log( trnForm.value.eDt);
    this.trnServ.insertTraining(trnForm.value.cId,
      trnForm.value.aCName,
      trnForm.value.sDt,
      trnForm.value.eDt ).subscribe(
        (data: any) => {
          this.retMsg = JSON.stringify(data);
          console.log( this.retMsg);
        },
        (error: any) => {
          this.retMsg = error;
          console.log( this.retMsg);
        }
      );


  }
}
