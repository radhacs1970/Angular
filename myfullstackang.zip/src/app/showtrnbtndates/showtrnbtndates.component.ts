import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TrainingService } from '../training.service';
import { Training } from '../training';
import { Student } from '../student';

@Component({
  selector: 'app-showtrnbtndates',
  templateUrl: './showtrnbtndates.component.html',
  styleUrls: ['./showtrnbtndates.component.css']
})
export class ShowtrnbtndatesComponent implements OnInit {
  guestId: string;
  gDetails: any;
  gStd: Student;

  trnDatesF: FormGroup;
  trnfailed: string;
  trnArr: Training[];
  errMsg: string;
  seltrnId: number;
  showtrnFlag: boolean = false;

  constructor(private fb: FormBuilder, 
              private trnserv: TrainingService) { }
  
  
  ngOnInit(): void {
    this.guestId = localStorage.getItem('guestId');
    this.gDetails = localStorage.getItem('guestObj');
    this.gStd =  JSON.parse(this.gDetails);
    console.log(' in trn ' + this.guestId);
    console.log(' in trn ' + this.gDetails);
    console.log(' in trn ' + this.gStd.fname);

    this.trnDatesF = this.fb.group({
      startDate: [null, [Validators.required]],
      endDate: [null, [Validators.required]]
    });
  }
  // tslint:disable-next-line:typedef
  get startDate() { return this.trnDatesF.get('startDate'); }
  get endDate() { return this.trnDatesF.get('endDate'); }

  validateDates() {
    let sD = new Date(this.trnDatesF.get('startDate').value);
    let eD = new Date(this.trnDatesF.get('endDate').value);
    let td = new Date();
    td.setHours(0, 0, 0, 0);
    sD.setHours(0, 0, 0, 0);
    eD.setHours(0, 0, 0, 0);
    if ( sD.getTime() >= td.getTime() &&
           eD.getTime() >= sD.getTime() ) {
      this.showtrnFlag = true;
      this.trnserv.showTrnBtwDates(
        this.trnDatesF.get('startDate').value,
        this.trnDatesF.get('endDate').value).subscribe(
          (data: Training[]) => {
            console.log( data );
            this.trnArr = data;
          },
          (error: any) => {
            this.errMsg = ' Not able to fetch the data from server. ';
            console.log( this.errMsg);
          }
        );

    } else {
          console.log( ' Invalid dates.');
      this.trnfailed = ' start date should be greater than or equal today and end date should be greater than or equal to start date'
      this.showtrnFlag = false;
    }

  }

  onChange(trnId: number, index: number, chk: boolean): void {
    this.seltrnId = trnId;
    // alert ('button clicked ' + htlId + ' checked : ' + chk);
  }
  selectATrn(){
    console.log(this.seltrnId);
    alert(this.seltrnId);
  }
}
