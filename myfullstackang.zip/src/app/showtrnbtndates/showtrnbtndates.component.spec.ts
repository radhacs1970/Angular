import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowtrnbtndatesComponent } from './showtrnbtndates.component';

describe('ShowtrnbtndatesComponent', () => {
  let component: ShowtrnbtndatesComponent;
  let fixture: ComponentFixture<ShowtrnbtndatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowtrnbtndatesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowtrnbtndatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
