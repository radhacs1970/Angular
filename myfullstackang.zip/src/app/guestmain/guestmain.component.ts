import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-guestmain',
  templateUrl: './guestmain.component.html',
  styleUrls: ['./guestmain.component.css']
})
export class GuestmainComponent implements OnInit, OnDestroy {
  
  guestId: string;
  sub: Subscription;
  constructor(private _activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {

    //this.guestId = this._activatedRoute.snapshot.params['guestId'];

    this.sub = this._activatedRoute.params.subscribe(
        params => {
          this.guestId = params['guestId'];
        }
    );
    console.log( 'from snapshot ' + this.guestId);
    localStorage.setItem('guestId', this.guestId);
  }
  ngOnDestroy(): void {
    this.sub.unsubscribe();
  }
}
