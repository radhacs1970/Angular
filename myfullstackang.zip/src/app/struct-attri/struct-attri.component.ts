import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-struct-attri',
  templateUrl: './struct-attri.component.html',
  styleUrls: ['./struct-attri.component.css']
})
export class StructAttriComponent implements OnInit {
  num: number;
  showMe: string;
  constructor() { }

  ngOnInit(): void {
  }

}
