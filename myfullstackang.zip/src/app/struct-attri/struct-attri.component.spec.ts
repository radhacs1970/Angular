import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StructAttriComponent } from './struct-attri.component';

describe('StructAttriComponent', () => {
  let component: StructAttriComponent;
  let fixture: ComponentFixture<StructAttriComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StructAttriComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StructAttriComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
