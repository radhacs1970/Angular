export class Training {
  constructor(public trnid: number,
              public courseId: number,
              public trnName: string,
              public courseStDate: string,
              public courseEndDate: string
  ) {
  }
}

