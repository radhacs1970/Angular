import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowmyguestdetailsComponent } from './showmyguestdetails.component';

describe('ShowmyguestdetailsComponent', () => {
  let component: ShowmyguestdetailsComponent;
  let fixture: ComponentFixture<ShowmyguestdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowmyguestdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowmyguestdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
