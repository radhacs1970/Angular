import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Student } from '../student';
import { JsonPipe } from '@angular/common';

@Component({
  selector: 'app-showmyguestdetails',
  templateUrl: './showmyguestdetails.component.html',
  styleUrls: ['./showmyguestdetails.component.css']
})
export class ShowmyguestdetailsComponent implements OnInit {
  guestId: string;
  gDetails: any;
  gStd: Student;
  constructor( ) { }

  ngOnInit(): void {
    this.guestId = localStorage.getItem('guestId');
    this.gDetails = localStorage.getItem('guestObj');
    this.gStd =  JSON.parse(this.gDetails);
    console.log(this.guestId);
  }

}
