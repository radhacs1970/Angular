import { Shape } from './shape';

describe('Shape', () => {
  it('should create an instance', () => {
    expect(new Shape()).toBeTruthy();
  });
});
