import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestbookinghistoryComponent } from './guestbookinghistory.component';

describe('GuestbookinghistoryComponent', () => {
  let component: GuestbookinghistoryComponent;
  let fixture: ComponentFixture<GuestbookinghistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GuestbookinghistoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GuestbookinghistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
