import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guestbookinghistory',
  templateUrl: './guestbookinghistory.component.html',
  styleUrls: ['./guestbookinghistory.component.css']
})
export class GuestbookinghistoryComponent implements OnInit {
  ngOnInit(): void {}
  constructor(){}
  /*
  guestId: string;
  gDetails: any;
  gt: guest;
  bookArr: Booking[];
  constructor( private bookserv: BookingService) { }

  ngOnInit(): void {
    this.guestId = localStorage.getItem('guestId');
    this.gDetails = localStorage.getItem('guestObj');
    this.gt =  JSON.parse(this.gDetails);
    console.log(this.gt);
    this.bookserv.getbookinghistory(this.gt.guestId).subscribe(
      (data: Booking[]) => {
        this.bookArr = data
        },
      (error: any) => {
        console.log(error);
      }
    );
  }
*/
}
