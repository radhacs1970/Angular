import { Training } from './training';

describe('Training', () => {
  it('should create an instance', () => {
    expect(new Training()).toBeTruthy();
  });
});
