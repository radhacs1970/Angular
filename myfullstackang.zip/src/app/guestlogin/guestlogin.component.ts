import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { StudentService } from '../student.service';
import { Student } from '../student';

@Component({
  selector: 'app-guestlogin',
  templateUrl: './guestlogin.component.html',
  styleUrls: ['./guestlogin.component.css']
})
export class GuestloginComponent implements OnInit {
  guser: string;
  loginForm: FormGroup;
  loginfailed: string;
  logStudent: Student;
   

  constructor(private fb: FormBuilder, private router: Router,
              private stdservice: StudentService) { }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      username: [null, [Validators.required, Validators.minLength(2)]],
      password: [null, [Validators.required, Validators.minLength(2),
        Validators.maxLength(8)]]
    });
    console.log(this.loginForm);
  }
  get username() { return this.loginForm.get('username'); }
  get password() { return this.loginForm.get('password'); }


  loginUser() {
    console.log(this.loginForm);
    let un: string;
    let ps: string;
    un = this.loginForm.get('username').value;
    ps = this.loginForm.get('password').value;
    console.log(un, ps);
    this.stdservice.validateLoginStudent(un, ps).subscribe(
      (data: Student) => {
          this.logStudent = data;
          if( this.logStudent != null ){
            console.log( ' ret value is ' + this.logStudent);
            localStorage.setItem('guestId', un);
            localStorage.setItem('guestObj',
                JSON.stringify( this.logStudent ));
            this.router.navigate(['/guestmain', un]);
          } else {
            this.loginfailed = 'Invalid username or password ';
          }
      },
      (error: any) => {
        this.loginfailed = 'Invalid username or password ';
        console.log( error );
      }

    );


/*
    let ret: boolean = this.validatelogin(un, ps);
    console.log ('ret ' , ret);
    if ( ret ){
        localStorage.setItem('guestId', un);
        this.router.navigate(['/guestmain', un]);
    }
    else {
          this.loginfailed = "Invalid User name and password.."
    }
*/
  }
  onsubmit(): void{
    console.log(this.guser);
    this.router.navigate(['/guestmain', this.guser]);
  }
  /*
  validatelogin(un: string, ps: string): boolean {
    let ret: boolean;
    if ( ps == 'rr@123')
      ret = true;
    else 
      ret = false;
    return ret;
  }
  */
    
}
