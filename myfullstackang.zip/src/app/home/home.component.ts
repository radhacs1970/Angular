import { Component, OnInit } from '@angular/core';
import { RoomService } from '../room.service';
import { Room } from '../room';
import { Router } from '@angular/router';
import { StudentService } from '../student.service';
import { Student } from '../student';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  constructor(private stdServ: StudentService,
              private  router: Router
            // , private roomserv: RoomService
              ) { }
  stdArr: Student[];
  errMsg: any;
  mypic = 'assets/img1.jpg';

  selStdId: any;

  ngOnInit(): void {
   // this.roomArr = this.roomserv.getAllrooms();
    this.stdServ.getAllStudents().subscribe(
      (data: Student[]) =>
          {
            console.log(data);
            this.stdArr = data;
          },
      (error: any) => {
        this.errMsg =  'Unable to receive the data ' + error;
        console.log(this.errMsg);
      }
    );
  }



  guestLogin(): void {
    alert( 'guest login');
    this.router.navigate(['/guestlogin']);
  }
  hotelLogin(): void {
    alert( 'hotel login');
    //  this.router.navigate(['/hotellogin']);
  }
  onChange(stId: number, index: number, chk: boolean): void {
    this.selStdId = stId;
    // alert ('button clicked ' + htlId + ' checked : ' + chk);
  }
  showOneStudent(){
    console.log(this.selStdId);
    alert(this.selStdId);
    //localStorage.setItem('stdselected', this.selStdId.toString() );
    this.router.navigate(['/onestd', this.selStdId]);
  }
}
