import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databind',
  templateUrl: './databind.component.html',
  styleUrls: ['./databind.component.css']
})
export class DatabindComponent implements OnInit {
  mystr: string;
  mynum: number;
  myusername: string;
  fname:string;

  constructor() { }

  ngOnInit(): void {
    this.mystr = " Example of string interpolation";
    this.mynum = 30* 6;
    this.myusername = 'Meena';
    this.fname = 'arjun';
  }

  myalert( mybtnmsg: string): void{
    alert(mybtnmsg);
  }

}
