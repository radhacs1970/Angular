import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'customdatepipe'
})
export class CustomdatepipePipe extends DatePipe implements PipeTransform {
  static readonly DATE_FMT = 'dd/MMM/yyyy';
  transform(value: any, ...args: any[]): any {
    return super.transform(value, CustomdatepipePipe.DATE_FMT);
  }
}
