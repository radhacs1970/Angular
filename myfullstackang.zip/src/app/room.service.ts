import { Injectable } from '@angular/core';
import { Room } from './room';

@Injectable({
  providedIn: 'root'
})
export class RoomService {
  roomArr: Room[];
  constructor() {
    this.roomArr = [
      new Room(101, 1, 'single', 1000),
      new Room(102, 1, 'deluxe', 2000),
      new Room(103, 2, 'duplex', 5000),
      new Room(104, 2, 'suite', 9000),
      new Room(105, 3, 'cottage', 20000),
      new Room(106, 3, 'AC', 1200)
    ];
   }
   getAllrooms(): Room[]{
     return this.roomArr;
   }
   addaRoom(rm: Room): void{
     this.roomArr.push(rm);
   }
}
