
export interface Food {
  appetizer: string;
  mainfood: string;
  displaydetails(): void;
}
