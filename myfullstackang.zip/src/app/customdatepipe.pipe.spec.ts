import { CustomdatepipePipe } from './customdatepipe.pipe';

describe('CustomdatepipePipe', () => {
  it('create an instance', () => {
    const pipe = new CustomdatepipePipe();
    expect(pipe).toBeTruthy();
  });
});
