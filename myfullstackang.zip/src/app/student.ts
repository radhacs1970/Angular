export class Student {

  constructor( public studentId: number,
               public fname: string,
               public email: string,
               public userId: string,
               public upassWord: string){}
}
