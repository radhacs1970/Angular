import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LearnreactformComponent } from './learnreactform.component';

describe('LearnreactformComponent', () => {
  let component: LearnreactformComponent;
  let fixture: ComponentFixture<LearnreactformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LearnreactformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LearnreactformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
