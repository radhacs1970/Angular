import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-learnreactform',
  templateUrl: './learnreactform.component.html',
  styleUrls: ['./learnreactform.component.css']
})
export class LearnreactformComponent implements OnInit {
  /* example 1
  rname = new FormControl('');
  constructor() { }

  
  updateName() {
    this.rname.setValue('Nancy');
  } */
/*
  profileForm = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
  });

  */

  profileForm = this.fb.group({
    firstName: ['', Validators.required],
    lastName: [''],
    address: this.fb.group({
      street: [''],
      city: [''],
      state: [''],
      zip: ['']
    }),
  });
  constructor(private fb: FormBuilder){}
  ngOnInit(): void {
  }
  onSubmit() {
    // TODO: Use EventEmitter with form value
    console.log(this.profileForm.value);
  }
}
