export class Shape {
  constructor(private color: string){
  }
  public getcolor(): string{
    return this.color;
  }
}
