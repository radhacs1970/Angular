export class Room {
  constructor(public roomNo: number,
              public hotelId: number,
              public roomType: string,
              public roomCost: number){
              }
}
