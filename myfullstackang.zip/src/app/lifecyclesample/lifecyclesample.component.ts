import { Component, OnInit, OnChanges,
  OnDestroy, AfterViewInit, AfterViewChecked,
  AfterContentInit, AfterContentChecked,
  SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-lifecyclesample',
  templateUrl: './lifecyclesample.component.html',
  styleUrls: ['./lifecyclesample.component.css']
})
export class LifecyclesampleComponent implements
  OnInit, OnChanges,
  OnDestroy, AfterViewInit, AfterViewChecked,
  AfterContentInit, AfterContentChecked {
  simpleInput: string = "A VALUE....";
  constructor() { }
  ngOnInit() {
    console.log("OnInit  called only once");
  }
  ngOnChanges(changes: SimpleChanges) {
    for (let propName in changes) {
      let chng = changes[propName];
      let cur = JSON.stringify(chng.currentValue);
      let prev = JSON.stringify(chng.previousValue);
      console.log(`${propName}: currentValue = 
        ${cur}, previousValue = ${prev}`);
    }
  }
  ngOnDestroy() {
    console.log("Ondestroy");
  }

  ngAfterContentInit() {
    console.log("After Content init");
  }

  ngAfterContentChecked() {
    console.log("Content Checked");
  }
  ngAfterViewInit() {
    console.log("After view init");
  }
  ngAfterViewChecked() {
    console.log("View Checked");
  }


}
