import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LifecyclesampleComponent } from './lifecyclesample.component';

describe('LifecyclesampleComponent', () => {
  let component: LifecyclesampleComponent;
  let fixture: ComponentFixture<LifecyclesampleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LifecyclesampleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LifecyclesampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
