import { Component, OnInit } from '@angular/core';
import { Food } from '../food';
import { Shape } from '../shape';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
//
// template: ` <div> INLINE TEMPLATE EXAMPLE </div>`,
@Component({
  selector: 'app-learntypescript',
  templateUrl: './learntypescript.component.html',
  styleUrls: ['./learntypescript.component.css'],
})
export class LearntypescriptComponent implements OnInit {
  instmsg: string;
  qparam: string;
  subscription: Subscription;

  constructor( private router: Router) {
    this.instmsg = 'Welcome for learning';
 }

  hellouser(): void {
    let k: number;
    let j: number;
    let apps = ['WhatsApp', 'Instagram', 'Facebook'];
    let playStore = new Array(apps.length);

    k = 9;
    j = 8;
    let m: number;
    m = k * j;
    console.log('result is ' + m);


    for (var i = 0; i < apps.length; i++) {
      playStore[i] = apps[i];
    }

    for (let j in playStore) {
      console.log("using for in " + playStore[j]);
      console.log("value of j is " + j);
    }
    //USE -- OF
    for (let ps of playStore) {
      console.log(ps); // 'WhatsApp', 'Instagram', 'Facebook'
    }
    playStore.push("gmail");
    playStore.push("bubbleshooter");

    playStore.forEach(
      function (value) {
        console.log('printing the details: ' + value);
      }
    );

    console.log("below is  object example");

    var person = {
      firstName: "Tom",
      lastName: "Hanks",
      sayHello: function () { }  //Type template 
    };
    person.sayHello = function () {
      console.log("hello " + person.firstName + ' ' + person.lastName);
    };
    person.sayHello();

  }
  ngOnInit(): void {
    console.log(' instance variable value is: ' + this.instmsg);
    /* this.subscription =
    this.router.routerState.root.queryParams.subscribe(
    (queryParam: any) => {
      this.qparam = queryParam['analytics'];
      console.log( this.qparam);
     }
    ); */
    this.qparam =
      this.router.routerState.snapshot.root.queryParams['analytics'];
    this.hellouser();
    this.samplefunctions();
    this.sampleAnonymousfunc();
    this.learnInterfaceClass();
    this.learnClass();
  }
  learnClass():void {
    let myshape: Shape = new Shape("olivegreen");
    console.log( myshape.getcolor());
    //console.log(myshape.color);
  }
  learnInterfaceClass(): void {
    let northIndian: Food = {
      appetizer : 'tomatosoap',
      mainfood : 'roti',
      displaydetails(): void {
        console.log( this.appetizer + ' ' + this.mainfood);
      }
    };
    northIndian.displaydetails();
  }

  sampleAnonymousfunc():void{
    let myanony = function(a: number, b: number):number{
      let c: number = a + b;
      return c;
    };
    let myassign: number;
    myassign = myanony(10,3) * 10;
    console.log(myassign);

    let mymsg = function():string{
        return "hai welcome";
    };
    console.log( mymsg());

  }
  samplefunctions(): void {
    let discountvalue: number;
    discountvalue = this.calculatediscount(200, 5);
    console.log ( '5 percent is ' + discountvalue);
    discountvalue = this.calculatediscount(200);
    console.log( 'use default ' + discountvalue);


    discountvalue = this.calcDiscNtimes(500, 5, 2);
    console.log( 'use optional val 2 ' + discountvalue);

    discountvalue = this.calcDiscNtimes(500, 5);
    console.log( 'use NO optional val' + discountvalue);

    discountvalue = this.calcDiscNtimes(3000);
    console.log( 'use NO optional val and use default' + discountvalue);
  }
  calculatediscount( total: number, discount: number = 10): number {
    let retval: number;
    retval = total * discount / 100;
    return retval;
  }
  calcDiscNtimes( total: number, discount: number= 10, ntime?: number): number{
    let retval: number;
    retval = total * discount / 100;
    if ( ntime ) {
      retval = retval * ntime;
    }
    return retval;
  }

}
