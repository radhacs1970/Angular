export class Guest {
  constructor(public guestId: number,
              public guestname: string,
              public guestphoneno: string,
              public guestwallet: number,
              public guestusername: string,
              public guestpassword: string) { }
}
