Completed topics:
Angular Intro, Module, Component, Databinding.

Oct-4-2021
Structural Directives: ngIf, ngFor, ngSwitch,
dependency injection, class, service
Router.
Oct -5-2021
routers-queryparam.
Attribute Directives,- ngClass, ngStyle, ng-content,
inline template, inline style,
Custom directives ,
Adding img and setting the src using typescript
lifecycle of component 
Communication between parent and child - @Input, @Output
Oct-6-2021
pipes, ReactiveForms
Oct-7-2021
HttpClient, HttpService, get and post
Oct-8-2021
ReactiveForms, TemplateDrivenForms



