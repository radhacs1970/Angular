import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse} from "@angular/common/http";
import {Country} from './country';
//import { catchError, map, tap } from 'rxjs/operators';
import {Observable} from 'rxjs';
 

@Injectable({
  providedIn: 'root'
})
export class HttpsService {
   
  
  constructor(private httpClient: HttpClient) { }
/*
  getData(){
    let url = "http://localhost:8888/mywebrest/rest/countries";
    return this.httpClient.get(url);
  }
*/

  getData (): Observable<Country[]> {
    let url = "http://localhost:8888/mywebrest/rest/countries";
  return this.httpClient.get<Country[]>(url);     
}
postCountryData(c:Country){
  let url = "http://localhost:8888/mywebrest/rest/countries/addjson";
  this.httpClient.post(url,c )
        .subscribe(
            data => {
                console.log("POST Request is successful ", data);
            },
            error => {
                console.log("Error", error);
            }
        );    
}
}
