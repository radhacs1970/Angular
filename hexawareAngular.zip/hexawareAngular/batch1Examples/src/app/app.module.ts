import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {RouterModule, Routes} from '@angular/router';
import {HttpClientModule} from "@angular/common/http";


import { AppComponent } from './app.component';
import { LearnTsComponent } from './learn-ts/learn-ts.component';
import { DataBindingComponent } from './data-binding/data-binding.component';
import { MyclassComponent } from './myclass/myclass.component';
import { MystyleComponent } from './mystyle/mystyle.component';
import { MyForComponentComponent } from './my-for-component/my-for-component.component';
import { EmployeeTitlePipesPipe } from './employee-title-pipes.pipe';
import { LearnFormTdComponent } from './learn-form-td/learn-form-td.component';
import { TemplateFormComponent } from './template-form/template-form.component';
import { HomeComponent } from './home/home.component';
 import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { ReactiveformsComponent } from './reactiveforms/reactiveforms.component';
import { ChildrouteComponent } from './childroute/childroute.component';
import { ChildoneComponent } from './childroute/childone.component';
import { ChildtwoComponent } from './childroute/childtwo.component';
import {CHILD_ROUTES} from './childroute/child.route';

import {HttpsService} from './https.service';
import { CountryComponent } from './country/country.component';
import { DatadrivenComponent } from './datadriven/datadriven.component';

const APP_ROUTES:Routes=[
  { path:'learnFormTD', component:LearnFormTdComponent},
  { path:'country', component:CountryComponent},
  { path:'datadriven', component:DatadrivenComponent},
  { path:'formEmp', component:TemplateFormComponent},
  { path:'dispEmp', component:MyForComponentComponent},
  { path:'home',component:HomeComponent},
  { path:'child',component:ChildrouteComponent, children: CHILD_ROUTES},
  { path:'employees/:code',component:EmployeeDetailsComponent},
  { path:'reactiveforms',component:ReactiveformsComponent},
  { path:'', redirectTo: '/home', pathMatch:'full'} 
];

@NgModule({
  declarations: [
    AppComponent,
    LearnTsComponent,
    DataBindingComponent,
    MyclassComponent,
    MyForComponentComponent,
    EmployeeTitlePipesPipe,
    LearnFormTdComponent,
    TemplateFormComponent,
    HomeComponent,
    EmployeeDetailsComponent,
    EmployeelistComponent,
    ReactiveformsComponent,
    ChildrouteComponent,
    ChildoneComponent,
    ChildtwoComponent,
    CountryComponent,
    DatadrivenComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot( APP_ROUTES )
  ],
  providers: [HttpsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
