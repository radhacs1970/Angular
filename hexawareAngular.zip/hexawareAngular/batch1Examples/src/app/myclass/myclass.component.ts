import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myclass',
  template:`
  Using Html class attribute: 
  <button class='colorClass'>My Button</button><br>
  Using class propery binding :<br>
  <button class='colorClass' [class]='classesToApply'>
      My Button </button> <br>
  true or false condition:
  <button class='colorClass' 
   [class.boldClass]='!applyBoldClass'>
      My Button </button> <br>
  Using ANGULAR ngClass DIRECTIVE:
  <button class='colorClass' 
  [ngClass]='addClassess()'>
     My Button </button> <br>
  `,
  styleUrls: ['./myclass.component.css']
})
export class MyclassComponent implements OnInit {
  constructor() { }
  ngOnInit() { }
  classesToApply: string = 'italicsClass boldClass';
  applyBoldClass : boolean = false;
  applyItalicsClass : boolean = false;

  addClassess(){
    let classes = {
      boldClass: this.applyBoldClass,
      italicClass: this.applyItalicsClass 
    };
    return classes;
  }
}
