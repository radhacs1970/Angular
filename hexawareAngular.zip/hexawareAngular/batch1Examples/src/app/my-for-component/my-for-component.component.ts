import { Component, OnInit } from '@angular/core';
import {EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-my-for-component',
  templateUrl: './my-for-component.component.html',
  styleUrls: ['./my-for-component.component.css']
})
export class MyForComponentComponent implements OnInit {
  
  
   employees: Employee[];
   constructor(private _employeeService: EmployeeService) {
   }
   ngOnInit() {
    this.employees = this._employeeService.getEmployees();  
   }
   getEmployees(): void {
    this.employees = this._employeeService.getEmployees();
   }
   
}
