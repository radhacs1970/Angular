import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyForComponentComponent } from './my-for-component.component';

describe('MyForComponentComponent', () => {
  let component: MyForComponentComponent;
  let fixture: ComponentFixture<MyForComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyForComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyForComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
