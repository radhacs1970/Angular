import {RouterModule, Routes} from '@angular/router';

import { TemplateFormComponent } from './template-form/template-form.component';
import {HomeComponent} from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { MyForComponentComponent } from './my-for-component/my-for-component.component';
//{} is a javascript object
const APP_ROUTES:Routes=[
  { path:'formEmp', component:TemplateFormComponent},
  { path:'dispEmp', component:MyForComponentComponent},
  { path:'home',component:HomeComponent},
  { path:'', redirectTo: '/home', pathMatch:'full'},
  { path:'**',component:PageNotFoundComponent}
];

export const routing = RouterModule.forRoot( APP_ROUTES );