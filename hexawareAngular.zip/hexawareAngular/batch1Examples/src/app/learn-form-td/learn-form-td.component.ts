import { Component, OnInit } from '@angular/core';
import { NgForm } from "@angular/forms";
import { Employee } from '../employee';


@Component({
  selector: 'app-learn-form-td',
  templateUrl: './learn-form-td.component.html',
  styles:[`
  .ng-invalid {
    border: 2px solid: red;
        };
  .ng-valid {
    border: 2px solid: green;
        };
  `]
})
export class LearnFormTdComponent implements OnInit {
  
  emp: Employee = {
    code: null,
    name: null,
    gender: null,
    annualSalary: 0,
    dateOfBirth: null
  };
  genders:[ 
    'male',
    'female'];

    
  constructor() { }
  ngOnInit() {   }
  OnSubmit( form: NgForm){
    console.log(form.value);
    console.log(this.emp.name);
  }
}
