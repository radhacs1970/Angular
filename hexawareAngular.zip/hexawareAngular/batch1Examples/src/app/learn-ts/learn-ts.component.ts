import { Component, OnInit } from '@angular/core';
import { Foodi } from '../foodi';
import { Menu } from '../menu'

@Component({
  selector: 'app-learn-ts',
  templateUrl: './learn-ts.component.html' 
})
export class LearnTsComponent implements OnInit {

  myString: string;
  //interface
  private ice_cream1 = {fName:"cone-ice", fCalories:200};
  dispFoodInterface(fd:Foodi):void{
    console.log("our food interface: "+ fd.fName + 
    " has " + fd.fCalories);
  }
  constructor() { }
  
  // instantiating the classes
  private sundayMenu= new Menu(
       ["pancakes","waffle","biscuits"],1);
  ngOnInit() {
   let  str: string;
   str = " This is a string";
   console.log(str);
 
   let num: number;
   num = 5;
   console.log("value is :"+ num);
   let aBoolean: boolean;
   aBoolean = false;
   console.log("aBoolean value is :"+aBoolean);
   this.dispFoodInterface(this.ice_cream1);

   this.sundayMenu.list();
  }

}
