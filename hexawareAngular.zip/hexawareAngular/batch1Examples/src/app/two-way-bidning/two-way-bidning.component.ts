import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-two-way-bidning',
  template:`
  <input type="text" [(ngModel)]="person.name">
  <input type="text" [(ngModel)]="person.name">
  `,
  styles: []
})
export class TwoWayBidningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
person = {name:'Radha',age:27}
}
