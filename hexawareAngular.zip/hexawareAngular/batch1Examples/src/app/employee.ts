import {IEmployee} from './iEmployee';

export class Employee implements IEmployee {
  
constructor(public code: string, public name: 
       string, public gender: string,
       public annualSalary: number, 
       public dateOfBirth: string) {
      }
      // Implementation of the interface method
    //computeMonthlySalary(annualSalary: number): number {
    //  return annualSalary / 12;
    //}
}
