export class Menu {

  items: Array<string>; // this is public variable
  pages: number; // public variable

  constructor( item_list: Array<string>, 
    totalpages: number){
// this keyword is mandatory to access the class members.
    this.items = item_list;
    this.pages = totalpages;
  }

  list(): void {
    console.log ( "our menu for today:");
    for ( var i= 0; i < this.items.length; i++){
      console.log(this.items[i]);
    }
  }

}
