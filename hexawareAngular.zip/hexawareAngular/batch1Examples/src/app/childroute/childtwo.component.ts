import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'childtwo',
  template: `
    <p>
      childtwo works!
    </p>
  `,
  styles: []
})
export class ChildtwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
