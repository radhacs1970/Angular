import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-childroute',
  templateUrl: './childroute.component.html',
  styleUrls: ['./childroute.component.css']
})
export class ChildrouteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
