import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'childone',
  template: `
    <p>
      childone works!
    </p>
  `,
  styles: []
})
export class ChildoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
