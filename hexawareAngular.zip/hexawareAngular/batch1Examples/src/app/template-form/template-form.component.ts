import { Component, OnInit,OnDestroy } from '@angular/core';
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import {EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-template-form',
  templateUrl: './template-form.component.html' 
})
export class TemplateFormComponent implements OnInit {
  emp: Employee = {
    code: null,
    name: null,
    gender: null,
    annualSalary: 0,
    dateOfBirth: null
  };
  constructor(private employeeService: EmployeeService,
    private router: Router) { }
  ngOnInit() { }
  OnSubmit( fm:NgForm){
    console.log(fm.value);
    this.employeeService.AddEmployees(fm.value);
    console.log("size is" + 
       this.employeeService.getEmployees().length);    
    this.router.navigate(['/dispEmp'])
  }

}
