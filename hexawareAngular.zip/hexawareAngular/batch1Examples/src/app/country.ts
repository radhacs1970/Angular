export class Country {
    //id: number;
    //countryName: String;
    //cse: string;
    constructor ( public id: number, 
        public countryName : String,
        public cse: string){

        }
}
