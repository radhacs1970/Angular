import { EmployeeTitlePipesPipe } from './employee-title-pipes.pipe';

describe('EmployeeTitlePipesPipe', () => {
  it('create an instance', () => {
    const pipe = new EmployeeTitlePipesPipe();
    expect(pipe).toBeTruthy();
  });
});
