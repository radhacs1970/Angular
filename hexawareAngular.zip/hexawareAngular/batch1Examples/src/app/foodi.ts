export interface Foodi{
  fName:string;
  fCalories: number;
}