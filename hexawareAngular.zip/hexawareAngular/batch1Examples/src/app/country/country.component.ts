import { Component, OnInit,HostBinding } from '@angular/core';
import { Response } from '@angular/Http';
import {HttpsService} from '../https.service';
 

import { Country } from '../Country';
import { slideInDownAnimation } from '../animation';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css'],
  animations: [ slideInDownAnimation ]
})
export class CountryComponent implements OnInit {

  @HostBinding('@routeAnimation') routeAnimation = true;
  @HostBinding('style.display')   display = 'block';
  @HostBinding('style.position')  position = 'absolute';

  countries : Country[] = [];
  errorMsg : any;

  constructor(private httpsService: HttpsService) { }

  ngOnInit() {

    this.httpsService.getData()
    .subscribe( 
      data => this.countries = data,
      error => this.errorMsg = error );

/*
    this.httpsService.getData().subscribe(
      data=> {
        const mArray=[];
        for ( let key in data){
          mArray.push(data[key]);
        }
        this.countries = mArray;
        console.log(this.countries);
      }
    );
  }
  */

  }
  addCountry(){
    let c: Country = new Country(99, 'newAng','vh');
    this.httpsService.postCountryData(c);

  }
}