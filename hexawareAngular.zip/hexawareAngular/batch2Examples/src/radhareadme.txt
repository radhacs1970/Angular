8/24/2018 - using templateurl , inline templateurl
 and styles and inline styles
 view encapsulation // shadow dom
 ngcontent in original component and fill text in the caller or parent component
string interapolation
property 
event
two way
--- done above

8/25/2018
see 015ngfor directive trackby, 
pipes, custom pipes, 
container and nested components
020 component input properties
021 component output properties

8/27/2018 -mon
lifecyle hooks, services, demo lifecycle

8/28/2018
services, di
8/29/2018
forms
8/30/2018
routing
31/8/2018
http
explain ng lint command

binding custom properties


**************
npm install @angular/cli
ng update @angular/cli