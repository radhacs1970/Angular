import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import {EmployeeService} from "../employee.service";

import { NgForm } from "@angular/forms";
@Component({
  selector: 'app-createemp',
  templateUrl: './createemp.component.html',
  styles:[`
  .ng-invalid {
    border: 2px solid: red;
        };
  .ng-valid {
    border: 2px solid: green;
        };
  `]
})
export class CreateempComponent implements OnInit {
  emp: Employee = {
    code: "emp101",
    name: "radha",
    gender: "male",
    annualSalary: 0,
    dateOfBirth: null
  };
  dobErr: String = "";
  constructor(private employeeService: EmployeeService) { }
  ngOnInit() {
  }
  OnSubmit( form: NgForm){
    
    console.log(form);
    var db = new Date(this.emp.dateOfBirth);
    var curd = new Date();
    curd.setDate(curd.getDate() - 1);
     
    if ( db > curd ) {
      this.dobErr = " date of birth is greater than today";
     
      return;
    }
    else {
       
      this.dobErr="";
    }
    this.employeeService.AddEmployees(this.emp);
  }
}
