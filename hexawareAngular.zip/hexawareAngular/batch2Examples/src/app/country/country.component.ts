import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {HttpsService} from '../https.service';
import { Country } from '../Country';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {
  countries : Country[] = [];
  constructor(private httpsService: HttpsService) { }
  ngOnInit() {
    
    this.httpsService.getData().subscribe(
      data=> {
        const mArray=[];
        for ( let key in data){
          mArray.push(data[key]);
        }
        this.countries = mArray;
        console.log(this.countries);
      }
    );
    /*
    this.httpsService.getData().subscribe(
      (res: any[] => {
        console.log(res);
        this.countries = res;
      }) 
    );*/
    
  }

}
