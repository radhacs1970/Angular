import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HooktestComponent } from './hooktest.component';

describe('HooktestComponent', () => {
  let component: HooktestComponent;
  let fixture: ComponentFixture<HooktestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HooktestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HooktestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
