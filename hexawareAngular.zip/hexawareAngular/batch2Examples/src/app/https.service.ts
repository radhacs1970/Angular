import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpsService {

  constructor(private httpClient: HttpClient) { }

  getData(){
  let url = "http://localhost:8888/mywebrest/rest/countries";
    return this.httpClient.get(url);
  }
}
