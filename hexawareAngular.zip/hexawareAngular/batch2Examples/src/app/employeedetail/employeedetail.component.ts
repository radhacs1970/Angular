import { Component, OnInit } from '@angular/core';
import {EmployeeService } from '../employee.service';
import { Employee } from '../employee';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-employeedetail',
  templateUrl: './employeedetail.component.html'']
})
export class EmployeedetailComponent implements OnInit {

  employee: Employee;
  statusMessage: string = 'Loading data. Please Wait..';
  
  constructor( 
    private _employeeService: EmployeeService,
    private _router:Router,
    private _activatedRoute: ActivatedRoute) {

     }
  ngOnInit() {
   let empCode: string = this._activatedRoute.snapshot.params['code'];
   this.employee = this._employeeService.getEmployeeByCode(empCode);
  }
  gotoEmployeeList():void{
    this._router.navigate(['/employeelist'])
  }
}
