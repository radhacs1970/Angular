import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample',
  template: `
    <p>
      sample works! inline style and inline template
    </p> 
    <ng-content></ng-content>
  `,
  styles: [
    `
  p  { 
    color: blue;
    border : 2 px solid;
   }
  `]
})
export class SampleComponent implements OnInit {
//
  constructor() { }

  ngOnInit() {
  }

}
