import { Component, OnInit } from '@angular/core';
import {EmployeeService} from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {

  employees: Employee[];
  constructor( private employeeServ : EmployeeService ) {  
  }
  ngOnInit() {
    this.employees = this.employeeServ.getEmployees();
  }
  addEmployees(){
    let emp : Employee = new Employee( 'default', 'default',  'Female',
             3000, '08/09/1988');
    this.employeeServ.AddEmployees(emp);
  } 
trackByEmpCode( index : number, employee: any): string {
  return;
}

getTotalEmployeesCount(): number {
  return this.employees.length;
}
getMaleEmployeesCount(): number {
  return this.employees.filter(e=>e.gender === 'Male').length;
}
getFemaleEmployeesCount(): number {
  //this.employees. //do sort
  return this.employees.filter(e=>e.gender === 'Female').length;
}
selectedEmployeeCountRadioButton : string = 'All';

OnEmployeeCountRadioButtonChange( sradioButtonVal: string) :void {
  this.selectedEmployeeCountRadioButton =sradioButtonVal;
  console.log(sradioButtonVal);
}
headingClick(str:String){
  console.log(str);
}

}

/*
 employees: any[] = [
    {
        code: 'emp101', name: 'Tom', gender: 'Male',
        annualSalary: 5500, dateOfBirth: '06/25/1988'
    },
    {
        code: 'emp102', name: 'Alex', gender: 'Male',
        annualSalary: 5700.95, dateOfBirth: '09/06/1982'
    },
    {
        code: 'emp103', name: 'Mike', gender: 'Male',
        annualSalary: 5900, dateOfBirth: '12/8/1979'
    },
    {
        code: 'emp104', name: 'Mary', gender: 'Female',
        annualSalary: 6500.826, dateOfBirth: '01/10/1980'
    },
];

getEmployees():void {
  this.employees = [
    {
      code: 'emp101', name: 'Tom', gender: 'Male',
      annualSalary: 5500, dateOfBirth: '06/25/1988'
    },
    {
      code: 'emp102', name: 'Alex', gender: 'Male',
      annualSalary: 5700.95, dateOfBirth: '9/6/1982'
    },
    {
      code: 'emp103', name: 'Mike', gender: 'Male',
      annualSalary: 5900, dateOfBirth: '12/8/1979'
    },
    {
      code: 'emp104', name: 'Mary', gender: 'Female',
      annualSalary: 6500.826, dateOfBirth: '01/10/1980'
    },
    {
      code: 'emp105', name: 'Nancy', gender: 'Female',
      annualSalary: 9000.826, dateOfBirth: '03/05/1985'
  },
];
}

*/