import { Food } from "./food";

export class Northindian implements Food {

    constructor( private special:string, 
        public fName:string ,
        public  fCalories: number,
    public fVegan?: string  ){
            
        }
        public display(){
            console.log( this.special,this.fName);
        }
}
