export class Country {
    id : number;
    countryName: String;
    cse: String;
}
