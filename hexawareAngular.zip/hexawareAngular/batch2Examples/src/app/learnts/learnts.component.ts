import { Component, OnInit } from '@angular/core';
import {Food} from '../food';
import {Northindian} from '../northindian';

@Component({
  selector: 'app-learnts',
  templateUrl: './learnts.component.html',
  styleUrls: ['./learnts.component.css']
})
export class LearntsComponent implements OnInit {

  private ice_cream1 = {fName:"cone-ice", fCalories:200};
  private ni:Northindian = new Northindian("sp","rice",100);
  
  dispFoodInterface(fd:Food):void{
    console.log("our food details: "+ fd.fName + 
    " has " + fd.fCalories);
    this.ni.display();
  }
  constructor() { }

  ngOnInit() {
   let  str: string;
   str = " This is a string";
   console.log(str);
   let num: number;
   num = 5;
   console.log("value is :"+ num);
   let aBoolean: boolean;
   aBoolean = false;
   console.log("aBoolean value is :"+aBoolean);
   let anyDt : any;
     anyDt = 100;
   console.log(anyDt);
   this.dispFoodInterface(this.ice_cream1);

    this.dispFoodInterface(this.ni);

   

  }

}
/*
   private ni:Northindian = new Northindian("rice",100);
   this.dispFoodInterface(this.ni);
*/