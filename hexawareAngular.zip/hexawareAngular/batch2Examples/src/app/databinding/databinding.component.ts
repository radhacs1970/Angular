import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databinding',
  templateUrl: './databinding.component.html',
  styleUrls: ['./databinding.component.css']
})
export class DatabindingComponent implements OnInit {

  stringInterpolation: string; 
  numberInterpolation: number = 10;
  fname = "Radha";  
  myalert(value:String):void{
    alert(value);
  }
  constructor() { }

  ngOnInit() {
    this.stringInterpolation = "String value";
  }
  

}
