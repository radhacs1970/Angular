import { Routes } from '@angular/router';
import { ChildoneComponent } from './childone.component';
import { ChildtwoComponent } from './childtwo.component';

export const CHILD_ROUTES:Routes=[
    { path:'one', component:ChildoneComponent},
    { path: 'two', component:ChildtwoComponent}
];
