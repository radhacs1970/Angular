import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router'
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { LearntsComponent } from './learnts/learnts.component';
import { DatabindingComponent } from './databinding/databinding.component';
import { DirectivesComponent } from './directives/directives.component';
import { SampleComponent } from './sample.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { EmployeeTitlePipe } from './employee-title.pipe';
import { EmployeeCountComponent } from './employee-count/employee-count.component';
import { HooktestComponent } from './hooktest/hooktest.component';
import { HomeComponent } from './home/home.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { EmployeedetailComponent } from './employeedetail/employeedetail.component';
import { ChildrouteComponent } from './childroute/childroute.component';
import { ChildoneComponent } from './childroute/childone.component';
import { ChildtwoComponent } from './childroute/childtwo.component';
import { CHILD_ROUTES } from './childroute/child.route';
import { CreateempComponent } from './createemp/createemp.component';
import { CountryComponent } from './country/country.component';
import {HttpsService} from './https.service';

/*{ path:'employees/:code',component:EmployeeDetailsComponent}, */
const APP_ROUTES:Routes=[
  { path:'home',component:HomeComponent},
  { path:'country', component:CountryComponent},
  { path:'createemp',component:CreateempComponent},
  { path:'childrenrouting',
       component:ChildrouteComponent, children: CHILD_ROUTES},
  { path:'employeelist',component:EmployeelistComponent},
  { path:'employee/:code',component:EmployeedetailComponent},
  { path:'', redirectTo: '/home', pathMatch:'full'} ,
  { path:'**',component:PagenotfoundComponent }
] 

@NgModule({
  declarations: [
    AppComponent,
    LearntsComponent,
    DatabindingComponent,
    DirectivesComponent,
    SampleComponent,
    EmployeelistComponent,
    EmployeeTitlePipe,
    EmployeeCountComponent,
    EmployeedetailComponent,
    HooktestComponent,
    HomeComponent,
    PagenotfoundComponent,
    EmployeedetailComponent,
    ChildrouteComponent,
    ChildoneComponent,
    ChildtwoComponent,
    CreateempComponent,
    CountryComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot( APP_ROUTES )
  ],
  providers: [HttpsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
