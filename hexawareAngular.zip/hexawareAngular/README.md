# hexawareAngular
for training demo
