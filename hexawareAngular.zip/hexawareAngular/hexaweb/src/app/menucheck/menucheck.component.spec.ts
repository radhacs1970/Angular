import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenucheckComponent } from './menucheck.component';

describe('MenucheckComponent', () => {
  let component: MenucheckComponent;
  let fixture: ComponentFixture<MenucheckComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenucheckComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenucheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
