import { Component, OnInit } from '@angular/core';
import { Menu } from '../menu';
import { MenuService } from '../menu.service';

@Component({
  selector: 'app-menucheck',
  templateUrl: './menucheck.component.html',
  styleUrls: ['./menucheck.component.css']
})
export class MenucheckComponent implements OnInit {

  menuItems: Menu[];
  checkArray : string[] = new Array();
  comment:string;
  msg: string;
    constructor( private menuserv: MenuService){}
  ngOnInit() {
    this.menuItems = this.menuserv.getAllMenu();
    console.log(this.menuItems);
    for (var x = 0; x<this.menuItems.length; x++) {
      this.checkArray.push("");
  } 
  }
  
  onChange(menuId:string, pos:number , isChecked: boolean) {
    console.log (menuId + " ps:  " + pos );
    console.log ( isChecked);
    this.msg="";
    if(isChecked) {
      this.checkArray[pos]  = menuId;
    } else {
      this.checkArray[pos]  = "";
      this.menuItems[pos].qty = undefined;
    }
  }
  onQtyClick(){
    let flag:boolean = false;
    for (var x = 0; x<this.menuItems.length; x++) {
      if ( this.checkArray[x].length > 0 ) {
        flag = true;
        console.log( "selected " + 
          this.menuItems[x].menuId + " " +
          this.menuItems[x].qty );
      }
      if ( flag == false )
        this.msg="Select atleast one menu item";
   }  
  }
  onClick( ){
    //this.comment = comment;
    console.log( this.comment);
    // Now add this comment to menu.
    for (var x = 0; x<this.menuItems.length; x++) {
       if ( this.checkArray[x].length > 0 ) {
         this.menuserv.updateCommentsInMenu(
          this.checkArray[x], this.comment );
          
       }

    } 
  }

}
