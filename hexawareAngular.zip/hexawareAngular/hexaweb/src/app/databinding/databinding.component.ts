import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databinding',
  templateUrl: './databinding.component.html',
  styleUrls: ['./databinding.component.css']
})
export class DatabindingComponent implements OnInit {
  stringInterpolation: string;
  numberInterpolation: number = 10;
  fname  = 'Geetha';
  constructor() { }

  ngOnInit() {
    this.stringInterpolation =  "Databinding String";
    this.numberInterpolation =  30;
//    this.fname = "Radha";
  }
  myalert(value:String):void{
    alert(value);
  }

}
