export class Student {
  constructor ( public regNo: string,
    public name :string,
    public dob:string){}
}
