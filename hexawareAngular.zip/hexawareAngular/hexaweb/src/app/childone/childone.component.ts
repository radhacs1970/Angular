import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-childone',
  templateUrl: './childone.component.html',
  styleUrls: ['./childone.component.css']
})
export class ChildoneComponent implements OnInit {
@Input()
msgtoChildOne :string; 

@Output()
  bclick : EventEmitter<string> = new EventEmitter<string>();
count : number;
  constructor() { }

  ngOnInit() {
    this.count = 0;
  }
  buttonclicked(){
    this.count++;
    this.bclick.emit("button is clicked " + this.count);
  }
}
