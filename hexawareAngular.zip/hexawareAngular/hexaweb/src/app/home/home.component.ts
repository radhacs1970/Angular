import { Component, OnInit } from '@angular/core';
import { Menu } from '../menu';
import { MenuService } from '../menu.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'] 
})
export class HomeComponent implements OnInit {
  menuItems: Menu[];
  birthday = new Date(1995,3,15); 
    constructor( private menuserv: MenuService){}
  ngOnInit() {
    this.menuItems = this.menuserv.getAllMenu();
    console.log(this.menuItems);
  }
}
