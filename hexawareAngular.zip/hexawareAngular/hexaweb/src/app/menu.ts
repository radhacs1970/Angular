export class Menu  
{
    public comment:string;
    public qty : number;
    constructor(  public menuId : string,
        public menuName: string,
        public menuPrice:number,
    public menuVendor: string,
    public menuCat:string) {}
}