import { Northindian } from './northindian';

describe('Northindian', () => {
  it('should create an instance', () => {
    expect(new Northindian()).toBeTruthy();
  });
});
