import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'datemonf'
})
export class DatemonfPipe extends DatePipe implements PipeTransform {
  static readonly DATE_FMT = 'dd/MMM/yyyy';
  transform(value: any, ...args: any[]): any {
    return super.transform(value, DatemonfPipe.DATE_FMT);;
  }

}
