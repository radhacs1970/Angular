import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sampleinline',
  template: `
    <p>
      sampleinline works is example inline template!<br>
      <ng-content></ng-content><br>
      This is another directive called ng content.
    </p>
  `,
  styles: [ 
    `
    p {
      background-color: lightgreen;
    }
    `
      ]
})
export class SampleinlineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
