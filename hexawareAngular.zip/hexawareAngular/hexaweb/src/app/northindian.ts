import { Food } from "./food";

export class Northindian implements Food
{
    constructor( private special:string, 
                    public fName:string , public  fCalories: number,
                public fVegan?: string  ){
        }
        public display(){
            console.log( 'special ' + this.special,'food ' + this.fName,
               'calories '+ this.fCalories );
        }
}
