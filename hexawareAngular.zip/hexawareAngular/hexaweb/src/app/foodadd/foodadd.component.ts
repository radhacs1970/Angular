import { Component, OnInit } from '@angular/core';
import { Menu } from '../menu';
import { NgForm } from '@angular/forms';
import { MenuService } from '../menu.service';

@Component({
  selector: 'app-foodadd',
  templateUrl: './foodadd.component.html',
  styleUrls: ['./foodadd.component.css'],

})
export class FoodaddComponent implements OnInit {

  menuNew : Menu = {
    menuId: "",
    menuName: "",
    menuPrice: 0,
    menuVendor: "",
    menuCat: "Vegetarian",
    comment:"",
    qty : 0
  };
 
  constructor( private mnuService:MenuService) { }
  ngOnInit() {  }  
  OnSubmit( form: NgForm){
   // console.log(form)
    console.log(this.menuNew);
    this.mnuService.addMenu(this.menuNew);
  }
}
