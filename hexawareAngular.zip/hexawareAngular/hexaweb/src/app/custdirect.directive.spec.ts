import { CustdirectDirective } from './custdirect.directive';

describe('CustdirectDirective', () => {
  it('should create an instance', () => {
    const directive = new CustdirectDirective();
    expect(directive).toBeTruthy();
  });
});
