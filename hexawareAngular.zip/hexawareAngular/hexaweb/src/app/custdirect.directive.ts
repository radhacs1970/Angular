import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: '[appCustdirect]'
})
export class CustdirectDirective {

  constructor(Element: ElementRef) { 
    console.log(Element);
    Element.nativeElement.innerText=
      "** newly add by Directive. **  ";
  }

}
// ng g directive custdirect