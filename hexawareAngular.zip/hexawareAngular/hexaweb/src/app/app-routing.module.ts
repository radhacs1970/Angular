import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MenudetailsComponent } from './menudetails/menudetails.component';
import { FoodaddComponent } from './foodadd/foodadd.component';
import { LoginformComponent } from './loginform/loginform.component';
import { ChildrouteComponent } from './childroute/childroute.component';
import { ChildoneComponent } from './childone/childone.component';
import { ChildtwoComponent } from './childtwo/childtwo.component';
import { MenucheckComponent } from './menucheck/menucheck.component';
import { StudentdbComponent } from './studentdb/studentdb.component';
import { StudentaddComponent } from './studentadd/studentadd.component';

const CHILD_ROUTES:Routes=[
  { path:'one', component:ChildoneComponent},
  { path: 'two', component:ChildtwoComponent}
];
const routes: Routes = [
  { path:'home',component:HomeComponent},
  { path:'menucheck',component:MenucheckComponent},
   { path:'student',component:StudentdbComponent},
   { path:'studentadd',component:StudentaddComponent},
  { path:'menu/:id',component:MenudetailsComponent},
  { path:'NewFoodItem',component:FoodaddComponent},
  { path:'login',component:LoginformComponent},
  { path:'childcomm',component:ChildrouteComponent,children: CHILD_ROUTES}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
