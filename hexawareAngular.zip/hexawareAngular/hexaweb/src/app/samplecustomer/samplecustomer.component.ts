import { Component, OnInit } from '@angular/core';
import { Menu } from '../menu';
import { MenuService } from '../menu.service';

@Component({
  selector: 'app-samplecustomer',
  templateUrl: './samplecustomer.component.html',
  styleUrls: ['./samplecustomer.component.css']
})
export class SamplecustomerComponent implements OnInit {
  menuItems: Menu[];
  selectedProduct : Menu ;
  constructor(private menuserv: MenuService) { }

  ngOnInit() {
    this.menuItems = this.menuserv.getAllMenu();
    this.selectedProduct =  this.menuItems[0];
  }
  onSelect(menuId) { 
    this.selectedProduct = null;
    for (var i = 0; i < this.menuItems.length; i++)
    {
      if (this.menuItems[i].menuId === menuId) {
        this.selectedProduct = this.menuItems[i];
      }
    }
}
}
