import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LearntsComponent } from './learnts/learnts.component';
import { DatabindingComponent } from './databinding/databinding.component';
import { SampleinlineComponent } from './sampleinline/sampleinline.component';
import { CustdirectDirective } from './custdirect.directive';
import { HighlightDirective } from './highlight.directive';
import { HomeComponent } from './home/home.component';
import { DatemonfPipe } from './datemonf.pipe';
import { MenudetailsComponent } from './menudetails/menudetails.component';
import { FoodaddComponent } from './foodadd/foodadd.component';
import { MenuService } from './menu.service';
import { SamplecustomerComponent } from './samplecustomer/samplecustomer.component';
import { LoginformComponent } from './loginform/loginform.component';
import { ChildrouteComponent } from './childroute/childroute.component';
import { ChildoneComponent } from './childone/childone.component';
import { ChildtwoComponent } from './childtwo/childtwo.component';
import { MenucheckComponent } from './menucheck/menucheck.component';
import { StudentdbComponent } from './studentdb/studentdb.component';
import { StudentaddComponent } from './studentadd/studentadd.component';

@NgModule({
  declarations: [
    AppComponent,
    LearntsComponent,
    DatabindingComponent,
    SampleinlineComponent,
    CustdirectDirective,
    HighlightDirective,
    HomeComponent,
    DatemonfPipe,
    MenudetailsComponent,
    FoodaddComponent,
    SamplecustomerComponent,
    LoginformComponent,
    ChildrouteComponent,
    ChildoneComponent,
    ChildtwoComponent,
    MenucheckComponent,
    StudentdbComponent,
    StudentaddComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
