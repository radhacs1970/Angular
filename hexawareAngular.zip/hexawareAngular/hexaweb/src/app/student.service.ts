import { Injectable } from '@angular/core';
import { Student } from './student';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  constructor(private http: HttpClient) { }
  getAllStudent(): Observable<Student[]>  {
    let url = 
    'http://localhost:8080/mywebapp/rest/student';
    return this.http.get<Student[]>(url);
  }

  postAddStudent(std: Student): 
          Observable<HttpResponse<String>> {
    let url = 
    'http://localhost:8080/mywebapp/rest/student/add';
    let httpHeaders = new HttpHeaders({
       'Content-Type' : 'application/json'
    });    
    return this.http.post<String>(url, std,
      {
        headers: httpHeaders,
        observe: 'response'
      }
    );
  } 
}
