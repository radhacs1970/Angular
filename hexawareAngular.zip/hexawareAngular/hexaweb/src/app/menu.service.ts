import { Injectable } from '@angular/core';
import { Menu } from './menu';

@Injectable({
  providedIn: 'root'
})
export class MenuService {
  private   menuArr: Menu[];
  constructor() {
    this.menuArr = [
      new Menu('1001', 'Idly', 20, '500','Vegetarian'),
      new Menu('1002', 'Dosa', 30, '500','Vegetarian'),
      new Menu('1003', 'Biryani', 100, '501','NonVegetarian'),
      new Menu('1004', 'Gobi', 70, '501','NonVegetarian'),
      new Menu('1005', 'Paratha', 50, '502','NonVegetrian'),
      new Menu('1006', 'Rice', 60, '503','Vegetarian')
    ];
  }
   getAllMenu(): Menu[] {
    return this.menuArr;
  }
   getMenudetails(argMenuId: String): Menu {
    for (let menu of this.menuArr) {
      let c = menu.menuId;
      if (c === argMenuId)
        return menu;
    }
    return null;
  }
   addMenu(argMnu: Menu):void{
    this.menuArr.push(argMnu);
  }

  updateCommentsInMenu( argMenuId :string, argComment :string ){
    for (var x = 0; x<this.menuArr.length; x++) {
       
      if (this.menuArr[x].menuId === argMenuId){
        this.menuArr[x].comment = argComment;
      }
    }
  }
    
}
/*
draw a flow chart  how the menu driven canteen management system 
software is 
1. placing the customer order
2. order accept or reject done by vendor.
  For the above 
  Need to specify the class name,function name,
 arguments details and return data types in detail
3. Name the classes and and functions are mocked for showing the menu details.
*/
