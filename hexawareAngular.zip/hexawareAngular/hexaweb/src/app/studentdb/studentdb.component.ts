import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { StudentService } from '../student.service';
@Component({
  selector: 'app-studentdb',
  templateUrl: './studentdb.component.html',
  styleUrls: ['./studentdb.component.css']
})
export class StudentdbComponent implements OnInit {

  stdList: Student[];
  errorMsg:String
   
    constructor( private stdService: StudentService){}
  ngOnInit() {
    this.stdService.getAllStudent()
      .subscribe( 
        data => this.stdList = data,
        error => this.errorMsg = error );
    console.log(this.stdList);
  }
}
