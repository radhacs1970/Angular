import { DatemonfPipe } from './datemonf.pipe';

describe('DatemonfPipe', () => {
  it('create an instance', () => {
    const pipe = new DatemonfPipe();
    expect(pipe).toBeTruthy();
  });
});
