import { Injectable } from '@angular/core';
import { Orders } from './Orders';
import { Menu } from './menu';

@Injectable({
  providedIn: 'root'
})
export class OrdersService {
  ordArr :Orders [];  
  constructor() { }
  
  placeOrder( custId : string, menu : Menu, qty : number ){
    let orderStatus= 'Ordered';
    let ord = new Orders(
      Orders.count,
      custId,menu.menuVendor,menu.menuId,menu.menuName,
      menu.menuPrice,qty,
      orderStatus);
      this.ordArr.push(ord);
  }
  getOrdersHistoryForCustomer( custId:string): Orders []{
     let tempArr: Orders[] = null;
    for (let ord of this.ordArr){
      let c = ord.custId
      if ( c  === custId)
        tempArr.push(ord);
    }
   return tempArr;
 } 
 getOrdersHistoryForVendor( vendorId:string): Orders []{
  let tempArr: Orders[] = null;

 for (let ord of this.ordArr){
   let c = ord.vendorId;
   if ( c  === vendorId)
     tempArr.push(ord);
 }
return tempArr;
} 
}
