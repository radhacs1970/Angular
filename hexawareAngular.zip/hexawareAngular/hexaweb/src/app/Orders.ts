export class Orders  
{
    public static  count : number = 1;
    constructor(  
        public orderId : number,
        public custId : string,
        public vendorId : string,
        public menuId : string,
        public menuName: string,
        public menuPrice:number,
        public orderQty : number,
        public orderStatus: string) {
            Orders.count ++;
        }
}