import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-studentadd',
  templateUrl: './studentadd.component.html',
  styleUrls: ['./studentadd.component.css']
})
export class StudentaddComponent implements OnInit {

  std : Student= {
    regNo: "",
    name: "",
    dob:"" };
  constructor(private stdService:StudentService) {
     
   }

  ngOnInit() {
  }
  onAdd(){
 
      console.log( this.std);
    this.stdService.postAddStudent(this.std).subscribe(
      res => { 
	      let result: String = res.body;
	      console.log(result ) //artcl.title);
	      console.log(res.headers.get('Content-Type'));		
	    },
	    err => {
	    console.log(err);
	  }
    );
  }

}
