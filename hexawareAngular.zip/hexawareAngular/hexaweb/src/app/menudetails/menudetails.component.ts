import { Component, OnInit } from '@angular/core';
import { Menu } from '../menu';
import { MenuService } from '../menu.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-menudetails',
  templateUrl: './menudetails.component.html',
  styleUrls: ['./menudetails.component.css']
})
export class MenudetailsComponent implements OnInit {
  menudetails: Menu;
  constructor(private _menuService: MenuService,
    private _router:Router,
    private _activatedRoute: ActivatedRoute) { }
    
  ngOnInit() {
    let menuCode: string = 
    this._activatedRoute.snapshot.params['id'];
    this.menudetails = this._menuService.getMenudetails(menuCode);
    console.log(this.menudetails);
  }

  gotoHome():void{
    this._router.navigate(['/home'])
  }
}
