import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-childroute',
  templateUrl: './childroute.component.html',
  styleUrls: ['./childroute.component.css']
})
export class ChildrouteComponent implements OnInit {
  var1 : string  = "hai all";
  msgFromchild:string;
  constructor() { }

  ngOnInit() {
   // this.var1 = "Welcome";
  }
  onChildButtonClicked(argMsgFromchild: string){
    this.msgFromchild =argMsgFromchild;
  }
}
