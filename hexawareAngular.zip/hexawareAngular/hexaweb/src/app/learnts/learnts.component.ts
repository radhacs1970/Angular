import { Component, OnInit } from '@angular/core';
import { Northindian } from '../northindian';

@Component({
  selector: 'app-learnts',
  templateUrl: './learnts.component.html',
  styleUrls: ['./learnts.component.css']
})
export class LearntsComponent implements OnInit {
  myname :string;
  private ni:Northindian = new Northindian("spl briyani","rice",100);
  
  constructor() { }
  public display(){
    let i = 5;
    let j = 10;
    let result = j * i;
    console.log(result);
  }  
  
  ngOnInit() {
   let  str: string;
   str = " This is a string";
   console.log(str);

   this.myname = 'radha';
   console.log( "my name is :" + this.myname);
 
   let num: number;
   num = 5;
   console.log("value is :"+ num);
   let aBoolean: boolean;
   aBoolean = false;
   console.log("aBoolean value is :"+aBoolean);
   this.ni.display();
   this.display();
  }

}
