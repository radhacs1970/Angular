import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-loginform',
  templateUrl: './loginform.component.html',
  styleUrls: ['./loginform.component.css']
})
export class LoginformComponent implements OnInit {
  
  loginForm: FormGroup;
  loginfailed : string;
    constructor(private fb: FormBuilder,
      private _router :Router) {
    }
    ngOnInit() { 
        this.loginForm = this.fb.group({
            username: [null, [Validators.required, Validators.minLength(4)]],
            password: [null, [Validators.required, Validators.minLength(4),
              Validators.maxLength(8)]]
        })
        console.log(this.loginForm);
    }
    get username() { return this.loginForm.get('username'); }
    get password() { return this.loginForm.get('password'); }

    loginUser() {
        console.log(this.loginForm);
        let un:string;
        let ps:string;
        un = this.loginForm.get('username').value;
        ps = this.loginForm.get('password').value;
        console.log(un, ps); 
        let ret :boolean = this.validatelogin(un,ps);
        console.log ('ret ' , ret);
        if ( ret )
          this._router.navigate(['/NewFoodItem'])
        else {
          this.loginfailed = "Invalid User name and password.."
        }
    } 
    validatelogin(un :string,ps :string):boolean {
       
      if ( un.localeCompare('radha') == 0 
        && ps.localeCompare('Password') == 0)
        return true;
        
      return false
    } 
}
