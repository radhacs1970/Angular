import { Injectable } from '@angular/core';
import { Student } from './student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  studentArr: Student[];
  constructor() { 

    this.studentArr = [
      new Student(1, 'mala', '01/01/1998', '123453421', 'mm@rr.com'),
      new Student(2, 'geetha', '01/02/2000', '944480565', 'geetha@rr.com'),
      new Student(3, 'rama', '01/03/2008', '875458585', 'rama@rr.com'),
      new Student(4, 'murugan', '01/04/2004', '741852963', 'murugan@rr.com'),
      new Student(5, 'mahesh', '01/04/2005', '147852369', 'mahesh@rr.com')
    ];
  }
  getAllStudents(): Student[]{
    return this.studentArr;
  }
  addAStudent( std: Student): void{
    this.studentArr.push(std);
  }

}
