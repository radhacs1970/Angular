import { Component, OnInit } from '@angular/core';
import { getLocaleDirection } from '@angular/common';

@Component({
  selector: 'app-learnts',
  templateUrl: './learnts.component.html',
  styleUrls: ['./learnts.component.css']
})
export class LearntsComponent implements OnInit {

  myname: string;
  newnum: number;
  flag: boolean;
  anytype: any;

  constructor() { }

  ngOnInit(): void {
    this.myname = 'radha';
    this.newnum = 10;
    this.flag = true;
    this.anytype = ' Hai, I hold any data type';
    console.log( this.myname , ' ' , this.newnum);
    console.log( "bool value is ", this.flag);
    console.log(this.anytype);
    this.anytype = 999;
    console.log(this.anytype);
    console.log( this.simplefunction() );
    this.sampleAnonymousfunc();
    this.learnArrays();
  }
  learnArrays():void {
    let apps = ['WhatsApp', 'Instagram', 'Facebook'];
    let playStore = new Array(apps.length);

    for (let i = 0; i < apps.length; i++) {
      playStore[i] = apps[i];
    }

    for (let j in playStore) {
          console.log('using for in' + playStore[j]);
          console.log('value of j is ' + j);
    }
    //USE -- OF
    for (let ps of playStore) {
      console.log(ps); // 'WhatsApp', 'Instagram', 'Facebook'
    }

    playStore.push("gmail");
    playStore.push("bubbleshooter");
    playStore.forEach(
      function (value){
        console.log('printing the details: ' + value);
      }
    );
  }
  simplefunction(): string{
    let greet: string;
    greet = 'greeting msg';
    let disc: number;

    disc = this.calculatediscount(300, 5);
    console.log(disc);
    disc = this.calculatediscount(300);
    console.log(disc);

    disc = this.calculatediscount(300, 2, 5);
    console.log(disc);
    return greet;
  }
  calculatediscount( total: number, discount: number = 10,
    ntime?: number): number {
    let retval: number;
    retval = total * discount / 100;
    if (ntime > 0){
        retval = retval * ntime;
    }
    return retval;
  }
  sampleAnonymousfunc():void{
    let myfunc = function (): string{
      return '"welcome"';
    };
    console.log(myfunc());
    let myadd = function(a: number, b: number): number{
      let c: number;
      c = a + b;
      return c;
    };
    let myresult: number;
    myresult = myadd(5, 6);
    console.log(myresult);

  }
}
