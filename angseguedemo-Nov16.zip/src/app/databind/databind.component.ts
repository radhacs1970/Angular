import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databind',
  templateUrl: './databind.component.html',
  styleUrls: ['./databind.component.css']
})
export class DatabindComponent implements OnInit {
  mystr: string;
  mynum: number;
  myusername: string;
  fname: string;
  myImg: string = '/assets/img1.jpg';

  constructor() { }

  ngOnInit(): void {
    this.mystr = 'Example for string interpolation';
    this.mynum = 10*90;
    this.myusername = 'mala';
    this.fname = 'geetha';
  }
  myeventprocess(msg: string): void {
    alert( msg );
    //console.log( this.myusername);
    //alert( this.myusername);
  }
}
