import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-structattri',
  templateUrl: './structattri.component.html',
  styleUrls: ['./structattri.component.css']
})
export class StructattriComponent implements OnInit {
  showMe: boolean;
  num: number;
  apps = ['WhatsApp', 'Instagram', 'Facebook'];

  constructor() { }

  ngOnInit(): void {
  }

}
