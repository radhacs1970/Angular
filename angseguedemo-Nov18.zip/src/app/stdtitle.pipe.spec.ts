import { StdtitlePipe } from './stdtitle.pipe';

describe('StdtitlePipe', () => {
  it('create an instance', () => {
    const pipe = new StdtitlePipe();
    expect(pipe).toBeTruthy();
  });
});
