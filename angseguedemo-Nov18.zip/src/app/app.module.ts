import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ɵclearResolutionOfComponentResourcesQueue } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LearntsComponent } from './learnts/learnts.component';
import { DatabindComponent } from './databind/databind.component';
import { StructattriComponent } from './structattri/structattri.component';
import { StudentComponent } from './student/student.component';
import { HighlightDirective } from './highlight.directive';
import { NgclassngstyleComponent } from './ngclassngstyle/ngclassngstyle.component';
import { StdtitlePipe } from './stdtitle.pipe';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { HomecomponentComponent } from './homecomponent/homecomponent.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { StudentdetailComponent } from './studentdetail/studentdetail.component';
import { ChildroutingComponent } from './childrouting/childrouting.component';
import { ReactformComponent } from './reactform/reactform.component';
import { LoginreactiveformComponent } from './loginreactiveform/loginreactiveform.component';
import { StdtemplateformComponent } from './stdtemplateform/stdtemplateform.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    LearntsComponent,
    DatabindComponent,
    StructattriComponent,
    StudentComponent,
    HighlightDirective,
    NgclassngstyleComponent,
    StdtitlePipe,
    ParentComponent,
    ChildComponent,
    HomecomponentComponent,
    PagenotfoundComponent,
    StudentdetailComponent,
    ChildroutingComponent,
    ReactformComponent,
    LoginreactiveformComponent,
    StdtemplateformComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

