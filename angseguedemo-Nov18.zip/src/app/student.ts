export class Student {

  constructor( public stdId: number,
               public stdName: string,
               public stdDob: string,
                public stdMobile: string,
                public stdEmail: string, 
                public stdGender: string,
                public stdPassword: string ){

  }

}
