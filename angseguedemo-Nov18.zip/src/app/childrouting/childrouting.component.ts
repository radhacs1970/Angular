import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-childrouting',
  templateUrl: './childrouting.component.html',
  styleUrls: ['./childrouting.component.css']
})
export class ChildroutingComponent implements OnInit {

  constructor(private router: Router) { }
//showchild/structattributes
  ngOnInit(): void {
    this.router.navigate(['/showchild', 'structattributes']);
  }

}
