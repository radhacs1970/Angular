import { Injectable } from '@angular/core';
import { Student } from './student';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  private baseurl =  'http://localhost:3000/';
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    })
  };
  
  studentArr: Student[];
  constructor(private httpClient: HttpClient ) { 
/*
    this.studentArr = [
      new Student(1, 'mala', '01/01/1998', '123453421', 'mm@rr.com', 'female',
      'password123'),
      new Student(2, 'geetha', '01/02/2000', '944480565', 'geetha@rr.com', 'female',
      'password123'),
      new Student(3, 'rama', '01/03/2008', '875458585', 'rama@rr.com', 'female',
      'password123'),
      new Student(4, 'murugan', '01/04/2004', '741852963', 'murugan@rr.com', 'male',
      'password789'),
      new Student(5, 'mahesh', '01/04/2005', '147852369', 'mahesh@rr.com', 'male',
      'password789')
    ];
    */
  }
  /*
   getAllStudents(): Student[]{
    return this.studentArr;
  } 
  
  
  getStudentById(stdId: number): Student{

    for ( let std of this.studentArr){
      console.log( std );
      if ( stdId == std.stdId)
        return std;
    }
    return null;
  }
  addAStudent( std: Student): void{
    this.studentArr.push(std);
  }
  */
//'http://localhost:3000/student'
 getAllStudents(): Observable<Student[]>{
   let url = this.baseurl + 'student';
   return this.httpClient.get<Student[]>(url);
  }
  //'http://localhost:3000/student/10'
  getStudentById(stdId: number): Observable<Student>{
    let url = this.baseurl + 'student/' + stdId;
    console.log(url);
    return this.httpClient.get<Student>(url);
  }
  addAStudent( std: Student): Observable<any> {
    let url = this.baseurl + 'student';
     
    return this.httpClient.post<any>(url,
      JSON.stringify( std ),
        this.httpOptions );
  }
  validateloginStudent( usr: string, pass: string): Student {
  
    for ( let std of this.studentArr){
      console.log( std );
      if ( usr == std.stdName && pass == std.stdPassword)
        return std;
    }
    return null;
  }
}
