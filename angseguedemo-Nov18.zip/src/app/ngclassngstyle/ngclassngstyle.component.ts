import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngclassngstyle',
  templateUrl: './ngclassngstyle.component.html',
  styleUrls: ['./ngclassngstyle.component.css']
})
export class NgclassngstyleComponent implements OnInit {
  classesToApply: string = 'italicsClass boldClass';
  applyBoldClass: boolean = true;
  applyItalicsClass: boolean = true;

  constructor() { }

  ngOnInit(): void {
  }
  addClassess(){
    let classes = {
      boldClass: this.applyBoldClass,
      italicsClass: this.applyItalicsClass,
      colorClass: true
    };
    return classes;
  }

  isBold: boolean = true;
  fontSize: number = 30;
  isItalic: boolean = true;

  addStyles(){
    let styles = {
      'font-weight': this.isBold ? 'bold' : 'normal',
      'font-style': this.isItalic ? 'italic' : 'normal',
      'font-size.px': this.fontSize
    };
    return styles;
  }

}
