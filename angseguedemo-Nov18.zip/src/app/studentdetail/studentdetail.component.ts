import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Student } from '../student';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-studentdetail',
  templateUrl: './studentdetail.component.html',
  styleUrls: ['./studentdetail.component.css']
})
export class StudentdetailComponent implements OnInit {
  stdId: number;
  stdObj: Student;
  constructor(private stdService: StudentService,
              private activateRoute: ActivatedRoute,
              private router: Router) { }

  ngOnInit(): void {
    this.stdId = this.activateRoute.snapshot.params['id'];
    //this.stdObj = this.stdService.getStudentById(this.stdId);

    this.stdService.getStudentById(this.stdId).subscribe(
      (data: Student) => {
        this.stdObj = data ;
      },
      (error: any) => {
        console.log( ' no students ..', this.stdId); 
      }
    );
  }
  gotostdlist(): void{
    this.router.navigate(['/student']);
  }
}
