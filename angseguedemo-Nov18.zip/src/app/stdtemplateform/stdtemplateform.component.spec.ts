import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StdtemplateformComponent } from './stdtemplateform.component';

describe('StdtemplateformComponent', () => {
  let component: StdtemplateformComponent;
  let fixture: ComponentFixture<StdtemplateformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StdtemplateformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StdtemplateformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
