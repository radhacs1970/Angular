import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-stdtemplateform',
  templateUrl: './stdtemplateform.component.html',
  styleUrls: ['./stdtemplateform.component.css']
})
export class StdtemplateformComponent implements OnInit {
  stdObj: Student = new Student(0, '', '', '', '', '', '');
  constructor(private stdServ: StudentService) { }

  ngOnInit(): void {
  }

  OnSubmit(stdForm: NgForm): boolean {
    console.log(stdForm.invalid);
    if ( stdForm.invalid )  
      return false;
    console.log(this.stdObj);
    this.stdServ.addAStudent(this.stdObj).subscribe(
      (data: any) => { console.log('success'); },
      (error:any) => { console.log( " failure "); }
    );
    return true;
  }
}
