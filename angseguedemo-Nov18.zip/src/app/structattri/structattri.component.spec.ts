import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StructattriComponent } from './structattri.component';

describe('StructattriComponent', () => {
  let component: StructattriComponent;
  let fixture: ComponentFixture<StructattriComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StructattriComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StructattriComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
