import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { StudentService } from '../student.service';
import { Student } from '../student';

@Component({
  selector: 'app-loginreactiveform',
  templateUrl: './loginreactiveform.component.html',
  styleUrls: ['./loginreactiveform.component.css']
})
export class LoginreactiveformComponent implements OnInit {

  loginForm: FormGroup;
  stdObj: Student;

  constructor(private fb: FormBuilder,
              private stdService: StudentService) { }

  ngOnInit(): void {
    this.loginForm = this.fb.group(
      {
        username:[null,[Validators.required,
              Validators.minLength(3)]],
        password:[null,[Validators.required, 
              Validators.minLength(3), Validators.maxLength(18)]]
      }
    );

  }
  get username() { return this.loginForm.get('username'); }
  get password() { return this.loginForm.get('password'); }

  loginUser(): boolean{

    let  usr = this.loginForm.get('username').value;
    let  passw = this.loginForm.get('password').value;
    this.stdObj = this.stdService.validateloginStudent(usr, passw);
    return true;

  }
}
