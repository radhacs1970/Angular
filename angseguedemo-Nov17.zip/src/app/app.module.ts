import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LearntsComponent } from './learnts/learnts.component';
import { DatabindComponent } from './databind/databind.component';
import { StructattriComponent } from './structattri/structattri.component';
import { StudentComponent } from './student/student.component';
import { HighlightDirective } from './highlight.directive';
import { NgclassngstyleComponent } from './ngclassngstyle/ngclassngstyle.component';
import { StdtitlePipe } from './stdtitle.pipe';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { HomecomponentComponent } from './homecomponent/homecomponent.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { StudentdetailComponent } from './studentdetail/studentdetail.component';
import { ChildroutingComponent } from './childrouting/childrouting.component';

@NgModule({
  declarations: [
    AppComponent,
    LearntsComponent,
    DatabindComponent,
    StructattriComponent,
    StudentComponent,
    HighlightDirective,
    NgclassngstyleComponent,
    StdtitlePipe,
    ParentComponent,
    ChildComponent,
    HomecomponentComponent,
    PagenotfoundComponent,
    StudentdetailComponent,
    ChildroutingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
