import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  pmsgToChild = ' parent is sending a message to child as property attribute';
  
  msgFromchild: string;

  constructor() { }

  ngOnInit(): void {
  }

  buttonClickOnChildComponent( argMsgFromchild: string ): void {
    this.msgFromchild = argMsgFromchild;
  }
}
