import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  mystudent: Student;
  mystdArr: Student[];
  myvalue: number = 9978;

  constructor(private stdserv: StudentService ) {
    this.mystudent = new Student(8, 'newmala',
    '10/02/1995', '9444909222', 'rr@rr.com', 'female');

  }

  ngOnInit(): void {
    console.log(this.mystudent.stdName);
    this.mystdArr = this.stdserv.getAllStudents();
    console.log(this.mystdArr);
  }
  addnewStudent(): void {
    this.stdserv.addAStudent(this.mystudent);
  }
}
