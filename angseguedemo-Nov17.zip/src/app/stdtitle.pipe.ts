import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'stdtitle'
})
export class StdtitlePipe implements PipeTransform {

  transform(value: any, gender: string): string {
    if ( gender.toLowerCase() == 'male'){
      return 'Mr.' + value;
    }
    else {
      return 'Ms.' + value;
    }
  }

}
