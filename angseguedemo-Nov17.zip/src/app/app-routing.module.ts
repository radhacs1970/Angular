import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DatabindComponent } from './databind/databind.component';
import { HomecomponentComponent } from './homecomponent/homecomponent.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { StudentComponent } from './student/student.component';
import { StructattriComponent } from './structattri/structattri.component';
import { ParentComponent } from './parent/parent.component';
import { NgclassngstyleComponent } from './ngclassngstyle/ngclassngstyle.component';
import { StudentdetailComponent } from './studentdetail/studentdetail.component';
import { ChildroutingComponent } from './childrouting/childrouting.component';

const childroutes: Routes = [
  {path: 'structattributes', component: StructattriComponent},
  {path: 'parentchild', component: ParentComponent},
  {path: 'ngclassstyle', component: NgclassngstyleComponent}
];

const routes: Routes = [
  {path: 'databind', component: DatabindComponent},
  {path: 'home', component: HomecomponentComponent},
  {path: 'student', component: StudentComponent},
  {path: 'student/:id', component: StudentdetailComponent},
  {path: 'showchild', component: ChildroutingComponent,
    children: childroutes},
  {path: '', redirectTo: '/home', pathMatch: 'full'},
  {path: '**', component: PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
