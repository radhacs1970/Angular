import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-homecomponent',
  templateUrl: './homecomponent.component.html',
  styleUrls: ['./homecomponent.component.css']
})
export class HomecomponentComponent implements OnInit, OnDestroy {
 

  myname: string;
  subscripton: Subscription;
  constructor( private router: Router) { }

  ngOnInit(): void {
    this.subscripton = 
      this.router.routerState.root.queryParams.subscribe(
      (queryParam: any) => this.myname = queryParam['name']
      );
  }

  ngOnDestroy(): void {
    this.subscripton.unsubscribe();
 }

}
